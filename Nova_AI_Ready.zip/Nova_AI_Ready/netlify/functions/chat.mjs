import OpenAI from "openai";
export default async (req) => {
  if (req.method !== "POST") return new Response(JSON.stringify({error:"استعمل POST لإرسال الرسائل."}),{status:405,headers:{"Content-Type":"application/json; charset=utf-8"}});
  if (!process.env.OPENAI_API_KEY) return new Response(JSON.stringify({error:"مفتاح OPENAI_API_KEY مازال ما تزادش في إعدادات Netlify."}),{status:500,headers:{"Content-Type":"application/json; charset=utf-8"}});
  try {
    const body=await req.json();
    const messages=(Array.isArray(body.messages)?body.messages:[]).filter(m=>m&&["user","assistant"].includes(m.role)&&typeof m.content==="string").slice(-20).map(m=>({role:m.role,content:m.content.slice(0,8000)}));
    if(!messages.length||!messages.some(m=>m.role==="user")) return new Response(JSON.stringify({error:"كتب رسالة أولاً."}),{status:400,headers:{"Content-Type":"application/json; charset=utf-8"}});
    const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const completion=await client.chat.completions.create({model:process.env.OPENAI_MODEL||"gpt-4.1-mini",messages:[{role:"system",content:"أنت Nova AI، مساعد مفيد وودود. أجب بلغة المستخدم، ويمكنك استعمال العربية الفصحى أو الدارجة المغربية حسب أسلوبه. كن واضحاً وصادقاً، ولا تدّعِ أنك ChatGPT أو أنك تملك قدرات غير متاحة."},...messages]});
    return new Response(JSON.stringify({reply:completion.choices?.[0]?.message?.content||"ما قدرتش نوجد جواب دابا."}),{status:200,headers:{"Content-Type":"application/json; charset=utf-8"}});
  } catch(error) {
    console.error("Nova AI function error:",error);
    const message=error?.status===401?"مفتاح API غير صحيح. راجع OPENAI_API_KEY في Netlify.":error?.status===429?"وصلتي لحد الاستعمال أو خاصك تراجع الفوترة وحدود API.":"وقع خطأ. راجع OPENAI_MODEL ومفتاح API في إعدادات Netlify.";
    return new Response(JSON.stringify({error:message}),{status:500,headers:{"Content-Type":"application/json; charset=utf-8"}});
  }
};